package limelightplatform;

import com.fasterxml.jackson.databind.JsonNode;

public class IntegrationCodeTest {


    public static void main(String[] args) throws Exception {
        
        IntegrationCodeTest codeTest = new IntegrationCodeTest(); 
        // Sample data set to test with
        JsonNode rootNode = codeTest.getData("people.json");

        // you can expect the following as headers
        String[] header = {"firstName", "lastName", "email", "phone", "postalCode"};


        // sample: print firstName output for first node
        codeTest.printField(header[0], rootNode.get(0));
        
        //TODO: Print the data into the console in a csv format, including a header line 
        // 'firstName', 'lastName' and 'email' are required fields, if any of these are missing the node is invalid, it shouldn't be printed
        // Phone must be a valid NA number, with only digits and no spaces, if not valid, do not include
        // PostalCode must be a valid Canadian postal code, all upper case with a space between the two sets eg. A1A 1A1, if not valid do not include
        // the print to the csv should be in the format seen in the header above
		
        //IF RUNNING FROM COMMAND LINE
        //compile from the root directory of the project: javac -classpath bin/*:resource/:src/ src/limelightplatform/*.java
        //run: java -cp bin/*:resource/:src/ limelightplatform.IntegrationCodeTest           
        // For Windows:
        //compile: javac -cp bin\*;resource\*;src\*; src\limelightplatform\IntegrationCodeTest.java src\limelightplatform\JSONReader.java
        // run: java -cp bin\*;resource\;src limelightplatform.IntegrationCodeTest 
    }
    
    
    public JsonNode getData(String fileName) throws Exception{
        return JSONReader.getFileContents(fileName);
    }
    
    public void printField(String fieldName, JsonNode node){
        System.out.println(node.get(fieldName).asText());
    }
    
}
